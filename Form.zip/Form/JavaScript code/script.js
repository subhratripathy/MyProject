		function validateform()
		{  
			
			 var name=document.myform.txtname.value;  
			 alert(name);
			 var x=document.myform.txtemail.value;   
			 var atposition=x.indexOf("@");  
			 var dotposition=x.lastIndexOf(".");  

			if (name==null || name=="")
			{  
		alert(name);
			  alert("Name can't be blank");  
			  return false;  
			}  
			else
			 {
				return true;	
			  }
				
			 if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length)
			{  
				alert("Please enter a valid e-mail address \n Eg:- abcd@xyz.com...);  
				return false;  
			} 			
			else
			  {
				return true;	
			   }
		}
